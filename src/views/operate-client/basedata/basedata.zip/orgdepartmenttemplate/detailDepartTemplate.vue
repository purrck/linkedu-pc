<template>
  <div>
    <div class="edit-box">
      <div v-if="pageState == 'add'">
        <div class="mb-20">基本信息
          <span class="cGrey">（注： <span class="cRed">*</span> 为必填信息）</span>
          <div style="border:1px solid #4A9388;width:29px;margin-top:5px"></div>
        </div>
        <el-form :label-position="'right'" class="schoolForm-rao"
                 label-width="200px" ref="formData" :inline="false" :model="formData" :rules="rules" size="small">


          <el-col :span="12">
            <el-form-item label="机构部门模板 *  :" prop="orgDepartTempName">
              <el-input v-model="formData.orgDepartTempName" maxlength="64"></el-input>
            </el-form-item>
          </el-col>


          <el-col :span="12">
            <el-form-item label="机构类型 *  :" prop="orgTypeCode">
              <el-select v-model="formData.orgTypeCode" placeholder="请您选择">
                <el-option v-for="orgTypeCodeItem in orgTypeCodeOptions"
                           :key="orgTypeCodeItem.name"
                           :label="orgTypeCodeItem.label" :value="orgTypeCodeItem.name">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>


          <el-col :span="12">
            <el-form-item label="生效时间 *  :" prop="effectiveDt">
              <el-date-picker v-model="formData.effectiveDt" type="datetime" placeholder="选择日期"
                              value-format="yyyy-MM-dd HH:mm"
                              :picker-options="pickTime"></el-date-picker>
            </el-form-item>
          </el-col>


          <el-col :span="12">
            <el-form-item label="失效时间 :" prop="expiryDt">
              <el-date-picker v-model="formData.expiryDt" type="datetime" placeholder="选择日期"
                              value-format="yyyy-MM-dd HH:mm"
                              :picker-options="pickTime"></el-date-picker>
            </el-form-item>
          </el-col>


          <el-col :span="12">
            <el-form-item label="当前应用 *  :" prop="isCurrent">
              <el-select v-model="formData.isCurrent" placeholder="请您选择">
                <el-option v-for="isCurrentItem in ynOptions" :key="isCurrentItem.name"
                           :label="isCurrentItem.label" :value="isCurrentItem.name">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>


          <el-col :span="12">
            <el-form-item label="部门模板状态 :" prop="departTempStatusCode">
              <el-select v-model="formData.departTempStatusCode" placeholder="请您选择">
                <el-option v-for="departTempStatusCodeItem in departTempStatusCodeOptions"
                           :key="departTempStatusCodeItem.name"
                           :label="departTempStatusCodeItem.label" :value="departTempStatusCodeItem.name">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>

          <div class="clearfix"></div>

        </el-form>
      </div>

      <div v-if="pageState == 'edit'">
        <div class="mb-20">基本信息
          <span class="cGrey">（注： <span class="cRed">*</span> 为必填信息）</span>
          <div style="border:1px solid #4A9388;width:29px;margin-top:5px"></div>
        </div>
        <el-form :label-position="'right'" class="schoolForm-rao"
                 label-width="200px" ref="formData" :inline="false" :model="formData" :rules="rules" size="small">


          <el-col :span="12">
            <el-form-item label="机构部门模板 *  :" prop="orgDepartTempName">
              <el-input v-model="formData.orgDepartTempName" maxlength="64"></el-input>
            </el-form-item>
          </el-col>


          <el-col :span="12">
            <el-form-item label="机构类型 *  :" prop="orgTypeCode">
              <el-select v-model="formData.orgTypeCode" placeholder="请您选择">
                <el-option v-for="orgTypeCodeItem in orgTypeCodeOptions"
                           :key="orgTypeCodeItem.name"
                           :label="orgTypeCodeItem.label" :value="orgTypeCodeItem.name">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>


          <el-col :span="12">
            <el-form-item label="生效时间 *  :" prop="effectiveDt">
              <el-date-picker v-model="formData.effectiveDt" type="datetime" placeholder="选择日期"
                              value-format="yyyy-MM-dd HH:mm"
                              :picker-options="pickTime"></el-date-picker>
            </el-form-item>
          </el-col>


          <el-col :span="12">
            <el-form-item label="失效时间 :" prop="expiryDt">
              <el-date-picker v-model="formData.expiryDt" type="datetime" placeholder="选择日期"
                              value-format="yyyy-MM-dd HH:mm"
                              :picker-options="pickTime"></el-date-picker>
            </el-form-item>
          </el-col>


          <el-col :span="12">
            <el-form-item label="当前应用 *  :" prop="isCurrent">
              <el-select v-model="formData.isCurrent" placeholder="请您选择">
                <el-option v-for="isCurrentItem in ynOptions" :key="isCurrentItem.name"
                           :label="isCurrentItem.label" :value="isCurrentItem.name">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>


          <el-col :span="12">
            <el-form-item label="部门模板状态 :" prop="departTempStatusCode">
              <el-select v-model="formData.departTempStatusCode" placeholder="请您选择">
                <el-option v-for="departTempStatusCodeItem in departTempStatusCodeOptions"
                           :key="departTempStatusCodeItem.name"
                           :label="departTempStatusCodeItem.label" :value="departTempStatusCodeItem.name">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>


          <div class="clearfix"></div>

        </el-form>
      </div>


      <div v-if="pageState == 'detail'">
        <el-row>
          <el-col :xs="20" :sm="20" :md="20" :lg="20" :xl="20">
            <h3 class="text-center mb-20">{{formData.schoolOrgName}}</h3>
            <div class="mb-20">基本信息
              <div style="border:1px solid #4A9388;width:29px;margin-top:5px"></div>
            </div>
            <!-- 详细查看 -->
            <el-form :label-position="'right'" class="schoolForm-rao schoolForm-detail-rao" label-width="165px"
                     :inline="true" :model="formData" size="small">


              <el-col :span="12" v-if="formData.orgDepartTempId">
                <el-form-item label="机构部门模板 :" prop="orgDepartTempId">
                  {{formData.orgDepartTempId}}
                </el-form-item>
              </el-col>


              <el-col :span="12" v-if="formData.orgDepartTempName">
                <el-form-item label="机构部门模板 :" prop="orgDepartTempName">
                  {{formData.orgDepartTempName}}
                </el-form-item>
              </el-col>


              <el-col :span="12">
                <el-form-item label="机构类型 :" prop="orgTypeCode"
                              :style="{'color':formData.orgTypeCodeStr.split(';')[1]}">
                  {{formData.orgTypeCodeStr.split(';')[0]}}
                </el-form-item>
              </el-col>


              <el-col :span="12">
                <el-form-item label="生效时间 :" prop="effectiveDt">
                  {{formData.effectiveDt}}
                </el-form-item>
              </el-col>


              <el-col :span="12">
                <el-form-item label="失效时间 :" prop="expiryDt">
                  {{formData.expiryDt}}
                </el-form-item>
              </el-col>


              <el-col :span="12">
                <el-form-item label="当前应用 :" prop="isCurrent">
                  <div v-if="formData.isCurrent == 'Y'">
                    <el-switch v-model="formData.onSwitchStatus" disabled></el-switch>
                  </div>
                  <div v-else>
                    <el-switch v-model="formData.offSwitchStatus" disabled></el-switch>
                  </div>
                </el-form-item>
              </el-col>


              <el-col :span="12">
                <el-form-item label="部门模板状态 :" prop="departTempStatusCode"
                              :style="{'color':formData.departTempStatusCodeStr.split(';')[1]}">
                  {{formData.departTempStatusCodeStr.split(';')[0]}}
                </el-form-item>
              </el-col>


              <el-col :span="12" v-if="formData.appOrgId">
                <el-form-item label="机构 :" prop="appOrgId">
                  {{formData.appOrgId}}
                </el-form-item>
              </el-col>


              <el-col :span="12" v-if="formData.appId">
                <el-form-item label="应用 :" prop="appId">
                  {{formData.appId}}
                </el-form-item>
              </el-col>


            </el-form>
          </el-col>

          <el-col :xs="4" :sm="4" :md="4" :lg="4" :xl="4">
            <div class="menu-quickly">
              <ul>
                <li>
                  <router-link :to="'/basedata/listTempDepart?orgDepartTempId='+formData.orgDepartTempId+'&orgDepartTempName='+formData.orgDepartTempName">
                    <img src="~@/assets/img/menu_quickly/icon_classinfo.png"/>模板部门
                  </router-link>
                </li>
              </ul>
            </div>
          </el-col>
        </el-row>
      </div>
      <div class="clearfix"></div>

      <div class="text-center">
        <el-button v-if="pageState == 'edit'" type="primary" class="mr80" :loading="formLoading" size="small"
                   @click="submit('formData')">更新
        </el-button>
        <el-button v-if="pageState == 'add'" type="primary" class="mr80" :loading="formLoading" size="small"
                   @click="submit('formData')">发布
        </el-button>
      </div>

    </div>
  </div>
</template>

<script>
  import api from "./orgdepartmenttemplateUrl";
  import validation from "@/util/validate2";
  import commonApi from "@/api/common/common";
  import editor from '@/components/editor/editor'
  import upload from '@/components/upload/uploadFileV1'

  export default {
    data() {
      return {
        xuantian: false, //选填信息
        formLoading: false,
        isLoaded: true,
        imagePath: [], //单独使用一个图片变量
        //getFileUrl: commonApi.getFileUrl(),
        //getImageUrl: commonApi.getImageUrl(),

        orgTypeCodeOptions: [{"label": "全部", "name": ""}], orgTypeCode: null,
        ynOptions: [{"label": "全部", "name": ""}], isCurrent: null,
        departTempStatusCodeOptions: [{"label": "全部", "name": ""}], departTempStatusCode: null,
        data: "",
        formData: {
          orgDepartTempId:null,
          orgDepartTempName: "",
          orgTypeCode: "",
          effectiveDt: "",
          expiryDt: "",
          isCurrent: "",
          departTempStatusCode: "",
        },
        pickTime: {
          disabledDate(time) {
            return time.getTime() < Date.now();
          }
        },
        rules: {
          orgDepartTempName: [
            {required: true, message: "请您输入机构部门模板", trigger: "blur"},
            {max: 64, message: "最多能输入64个字", trigger: "blur"},

          ],
          orgTypeCode: [
            {required: true, message: "请您输入机构类型", trigger: "blur"},
            {max: 32, message: "最多能输入32个字", trigger: "blur"},

          ],
          effectiveDt: [
            {required: true, message: "请您输入生效时间", trigger: "blur"},

          ],
          expiryDt: [],
          isCurrent: [
            {required: true, message: "请您输入当前应用", trigger: "blur"},
            {max: 2, message: "最多能输入2个字", trigger: "blur"},

          ],
          departTempStatusCode: [
            {max: 32, message: "最多能输入32个字", trigger: "blur"},

          ],
        }
      }
    },
    computed: {

      pageState() {
        return this.$route.params.type;
      }
    },
    components: {editor, upload},
    created() {
      this.getDetail(this.$route.params.id);
      commonApi.getCodeIntType("orgType").then(res => {
        let viewList = res.data.data || [];
        for (let orgTypeItem of viewList) {
          this.orgTypeCodeOptions.push({
            "label": orgTypeItem.codeDesc,
            "name": orgTypeItem.codeId
          });
        }
      }, res => {
        this.$message.error(res.data.message);
      });
      commonApi.getCodeIntType("boolean_yn").then(res => {
        let viewList = res.data.data || [];
        for (let ynItem of viewList) {
          this.ynOptions.push({
            "label": ynItem.codeDesc,
            "name": ynItem.codeId
          });
        }
      }, res => {
        this.$message.error(res.data.message);
      });
      commonApi.getCodeIntType("departTempStatus").then(res => {
        let viewList = res.data.data || [];
        for (let departTempStatusItem of viewList) {
          this.departTempStatusCodeOptions.push({
            "label": departTempStatusItem.codeDesc,
            "name": departTempStatusItem.codeId
          });
        }
      }, res => {
        this.$message.error(res.data.message);
      });
    },
    methods: {
      //图片上传
      uploadData(res) {
        this.formData.imagePath = res;
      },
      //编辑器
      getEditorValue(val) {
        this.formData.content = val
      },
      //选填信息
      xuantianHandler() {
        this.xuantian = this.xuantian ? false : true;
      },
      submit(formName) {
        const set = this.$refs;
        this.isLoaded = true;
        set[formName].validate(valid => {
          if (this.pageState === "edit" && valid) {
                this.formLoading = true;
            api.putObj(this.formData).then(res => {

              if (res.data.resultCode == "000000") {
                this.formLoading = false;
                this.$message.success("修改成功");
                this.$router.go(-1)
              } else {
                //this.$message.error(res.data.message);
                this.formLoading = false;
              }
            }, res => {
              this.$message.error("加载失败");
              this.formLoading = false;
            })
          } else if (this.pageState === "add" && valid) {
                this.formLoading = true;
            api.addObj(this.formData).then(res => {
              if (res.data.resultCode == "000000") {
                this.formLoading = false;
                this.$message.success("修改成功");
                this.$router.go(-1)
              } else {
                this.$message.error(res.data.message);
                this.formLoading = false;
              }
            }, res => {
              this.$message.error("加载失败");
              this.formLoading = false;
            })
          }
        })
        this.isLoaded = false;

      },


      getDetail(paramsId) {
        if (this.pageState !== 'add') {
          api.getObj(paramsId).then(res => {
            if (res.data.resultCode == "000000") {
              this.data = res.data.data;
              this.formData = res.data.data;


            }
            this.isLoaded = false;
          }, res => {
            this.$message.error(res.message);
          });
        }
      }
    }
  }
</script>
<style lang="scss" scoped>


  .el-form-item--small.el-form-item {
    margin-bottom: 25px;
  }

  .schoolForm-detail-rao {

    .el-form-item {
      margin-bottom: 5px;
    }

  }

  .ml80 {
    margin-left: 80px;
  }


</style>
